
module.exports = {
  SESSION_ID: "",  // add your Session Id here
  
  OWNER_NUMBER: "263714757857", // put your phone number here
  
  PREFIX: ".", // prefix (e.g., ., /, !, *)
  
  TIMEZONE: "Africa/Harare" //put your country timeZone....leave blank if u don't know.
};
